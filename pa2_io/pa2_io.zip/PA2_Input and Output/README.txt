This folder contains the input file for
your program and corresponding output files.
The input file names are based on project description.

To check your code, you can compare your result with:
1-  PA2_heap_output.  ---> For the first part of the project
    where "heap" is your first parameter
2-  PA2_minmedianmax_output.txt ---> For the second part of
    the project where "minmedianmax" is your firs parameter